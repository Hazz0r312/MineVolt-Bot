# 🎫 MineVolt Ticket Bot

Bot profesional de tickets para Discord — MineVolt Network

---

## ⚡ Instalación rápida

### 1. Requisitos
- Node.js 18 o superior → https://nodejs.org
- Una cuenta de Discord Developer

### 2. Crear el bot en Discord
1. Ve a https://discord.com/developers/applications
2. Haz clic en **New Application** → ponle un nombre
3. Ve a **Bot** → **Add Bot**
4. Activa los **Privileged Gateway Intents**:
   - ✅ SERVER MEMBERS INTENT
   - ✅ MESSAGE CONTENT INTENT
5. Copia el **Token** del bot

### 3. Invitar el bot al servidor
En **OAuth2 > URL Generator** selecciona:
- Scopes: `bot`, `applications.commands`
- Bot Permissions: `Administrator` (o ajusta manualmente)

Usa la URL generada para invitar el bot.

### 4. Configurar el bot

Copia `.env.example` a `.env` y rellena los valores:

```bash
cp .env.example .env
```

Edita `.env`:
```
DISCORD_TOKEN=tu_token_aqui
STAFF_ROLE_ID=id_del_rol_staff
TICKET_CATEGORY_ID=id_de_la_categoria
LOG_CHANNEL_ID=id_canal_logs
```

> **¿Cómo obtener IDs?** Activa el **Modo Desarrollador** en Discord
> (Ajustes > Avanzado > Modo desarrollador) y haz clic derecho sobre
> cualquier rol/canal para ver "Copiar ID".

### 5. Instalar dependencias e iniciar

```bash
npm install
node index.js
```

---

## 📋 Comandos

| Comando | Descripción | Permisos |
|---------|-------------|----------|
| `!panel` | Publica el panel de tickets en el canal actual | Gestionar canales |
| `!ip` | Muestra la IP y puerto del servidor | Todos |

---

## 🎫 Categorías de tickets

| Categoría | Descripción |
|-----------|-------------|
| 🔧 Soporte Técnico | Dudas y ayuda general |
| 📋 Reportar Usuario | Jugadores que incumplen normas |
| ⚠️ Reportar Bug | Fallos en el servidor |
| 🖥️ Sanciones & AntiCheat | Apelaciones de ban/mute |
| 💰 Pagos & Tienda | Problemas con compras |
| 💀 Solicitar Revive | Recuperar objetos por muerte injusta |
| ✏️ Postulaciones Staff | Unirse al equipo |
| 🚫 Reportar Staff | Denunciar comportamiento del staff |
| 🎉 Reclamar Sorteo | Cobrar premios de sorteos |

---

## 🔧 Estructura de archivos

```
bot/
├── index.js        ← Código principal del bot
├── package.json    ← Dependencias
├── .env.example    ← Plantilla de configuración
└── README.md       ← Este archivo
```

---

## ☁️ Hosting recomendado

- **Railway** → https://railway.app (gratis con límites)
- **Render** → https://render.com
- **VPS propio** con `pm2`: `npm install -g pm2 && pm2 start index.js`

---

**MineVolt Network • minevolt.fun**
