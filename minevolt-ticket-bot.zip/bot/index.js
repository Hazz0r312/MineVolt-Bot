const {
  Client,
  GatewayIntentBits,
  Partials,
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  PermissionFlagsBits,
  Collection,
} = require("discord.js");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
  ],
  partials: [Partials.Channel],
});

// ─── CONFIG ────────────────────────────────────────────────────────────────────
const CONFIG = {
  TOKEN: process.env.DISCORD_TOKEN || "MTUwNzgxNTcwNzk1NjQ4MjA2OA.GGfhDO.Ydi7YqiI_TaDCoiKp0QS5FTb05u8uh8AjnU8as",
  STAFF_ROLE_ID: process.env.STAFF_ROLE_ID || "1470849176912007213",
  TICKET_CATEGORY_ID: process.env.TICKET_CATEGORY_ID || "1483209640870281247",
  LOG_CHANNEL_ID: process.env.LOG_CHANNEL_ID || "1507033388132077689",
  SERVER_IP: "minevolt.fun",
  SERVER_PORT: "19132",
  COLOR_PRIMARY: 0x2b2d31,
  COLOR_SUCCESS: 0x57f287,
  COLOR_ERROR: 0xed4245,
  COLOR_WARNING: 0xfee75c,
  COLOR_INFO: 0x5865f2,
};

// ─── TICKET CATEGORIES ─────────────────────────────────────────────────────────
const TICKET_TYPES = {
  soporte: {
    label: "🔧 Soporte Técnico",
    description: "Dudas, errores o ayuda general del servidor",
    emoji: "🔧",
    color: 0x5865f2,
    prefix: "soporte",
  },
  reporte_usuario: {
    label: "📋 Reportar Usuario",
    description: "Denuncia jugadores que incumplan las normas",
    emoji: "📋",
    color: 0xfee75c,
    prefix: "reporte",
  },
  reporte_bug: {
    label: "⚠️ Reportar Bug",
    description: "Informa de fallos o errores en el servidor",
    emoji: "⚠️",
    color: 0xed4245,
    prefix: "bug",
  },
  sancion: {
    label: "🖥️ Sanciones & AntiCheat",
    description: "Apelaciones de ban, mute u otras sanciones",
    emoji: "🖥️",
    color: 0xeb459e,
    prefix: "sancion",
  },
  tienda: {
    label: "💰 Pagos & Tienda",
    description: "Problemas con compras o pagos en la tienda",
    emoji: "💰",
    color: 0x57f287,
    prefix: "tienda",
  },
  revive: {
    label: "💀 Solicitar Revive",
    description: "¿Moriste por un error? Solicita recuperar tus objetos",
    emoji: "💀",
    color: 0x9b59b6,
    prefix: "revive",
  },
  staff: {
    label: "✏️ Postulaciones Staff",
    description: "Únete al equipo de administración del servidor",
    emoji: "✏️",
    color: 0x1abc9c,
    prefix: "postula",
  },
  reporte_staff: {
    label: "🚫 Reportar Staff",
    description: "Denuncia comportamiento inapropiado de un miembro del staff",
    emoji: "🚫",
    color: 0xe74c3c,
    prefix: "rstaff",
  },
  sorteo: {
    label: "🎉 Reclamar Sorteo",
    description: "Ganaste un sorteo y quieres reclamar tu premio",
    emoji: "🎉",
    color: 0xf1c40f,
    prefix: "sorteo",
  },
};

// ─── TICKET COUNTER ────────────────────────────────────────────────────────────
let ticketCounter = 1;

// ─── READY ────────────────────────────────────────────────────────────────────
client.once("ready", () => {
  console.log(`✅ Bot conectado como ${client.user.tag}`);
  client.user.setActivity("⚡ minevolt.fun | !panel", { type: 3 });
});

// ─── MESSAGE CREATE ────────────────────────────────────────────────────────────
client.on("messageCreate", async (message) => {
  if (message.author.bot) return;
  if (!message.guild) return;

  const prefix = "!";
  if (!message.content.startsWith(prefix)) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  // ── !panel ──────────────────────────────────────────────────────────────────
  if (command === "panel") {
    if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
      return message.reply({
        content: "❌ No tienes permisos para usar este comando.",
        ephemeral: true,
      });
    }

    await message.delete().catch(() => {});
    await sendTicketPanel(message.channel);
  }

  // ── !ip ─────────────────────────────────────────────────────────────────────
  if (command === "ip") {
    const embed = new EmbedBuilder()
      .setColor(CONFIG.COLOR_INFO)
      .setTitle("⚡ Conecta a MineVolt")
      .setDescription(
        [
          "```",
          `IP  : ${CONFIG.SERVER_IP}`,
          `Puerto: ${CONFIG.SERVER_PORT}`,
          "```",
          "",
          "> Versión: **Java & Bedrock**",
          "> Web: **https://minevolt.fun**",
        ].join("\n")
      )
      .setThumbnail(
        "https://api.mcsrvstat.us/icon/minevolt.fun"
      )
      .setFooter({ text: "MineVolt Network • ¡Nos vemos en el juego!" })
      .setTimestamp();

    message.reply({ embeds: [embed] });
  }
});

// ─── SEND PANEL ───────────────────────────────────────────────────────────────
async function sendTicketPanel(channel) {
  const mainEmbed = new EmbedBuilder()
    .setColor(CONFIG.COLOR_PRIMARY)
    .setTitle("🎫 ¿NECESITAS AYUDA? ABRE UN TICKET")
    .setDescription(
      [
        "¡Bienvenido al sistema de soporte de **MineVolt**! Nuestro equipo de Staff y Administración está listo para ayudarte.",
        "Selecciona la categoría que mejor se adapte a tu situación.",
        "",
        "**⚠️ ANTES DE ABRIR UN TICKET:**",
        "• No menciones al Staff sin motivo, podría acarrearte una sanción.",
        "• No abras tickets sin razón válida, serán cerrados automáticamente.",
        "• Sé claro y aporta pruebas si las tienes.",
      ].join("\n")
    )
    .addFields(
      {
        name: "🔧 Soporte Técnico",
        value: "Dudas u errores generales",
        inline: true,
      },
      {
        name: "📋 Reportar Usuario",
        value: "Jugadores infractores",
        inline: true,
      },
      {
        name: "⚠️ Reportar Bug",
        value: "Fallos en el servidor",
        inline: true,
      },
      {
        name: "🖥️ Sanciones",
        value: "Apelaciones de ban/mute",
        inline: true,
      },
      {
        name: "💰 Pagos & Tienda",
        value: "Problemas con compras",
        inline: true,
      },
      { name: "💀 Revive", value: "Recupera tus objetos", inline: true },
      {
        name: "✏️ Staff/Media",
        value: "Únete al equipo",
        inline: true,
      },
      {
        name: "🚫 Reportar Staff",
        value: "Comportamiento inapropiado",
        inline: true,
      },
      { name: "🎉 Reclamar Sorteo", value: "Cobra tu premio", inline: true }
    )
    .setFooter({ text: "MineVolt Network • minevolt.fun" })
    .setTimestamp();

  const selectMenu = new StringSelectMenuBuilder()
    .setCustomId("ticket_select")
    .setPlaceholder("📂 Selecciona el tipo de ticket que deseas abrir...")
    .addOptions(
      Object.entries(TICKET_TYPES).map(([key, val]) => ({
        label: val.label,
        description: val.description,
        value: key,
        emoji: val.emoji,
      }))
    );

  const row = new ActionRowBuilder().addComponents(selectMenu);

  await channel.send({ embeds: [mainEmbed], components: [row] });
}

// ─── INTERACTION CREATE ────────────────────────────────────────────────────────
client.on("interactionCreate", async (interaction) => {
  // ── SELECT MENU ─────────────────────────────────────────────────────────────
  if (interaction.isStringSelectMenu() && interaction.customId === "ticket_select") {
    await interaction.deferReply({ ephemeral: true });

    const type = interaction.values[0];
    const ticketInfo = TICKET_TYPES[type];
    const guild = interaction.guild;
    const member = interaction.member;

    // Check existing ticket
    const existing = guild.channels.cache.find(
      (c) =>
        c.name.startsWith(ticketInfo.prefix + "-") &&
        c.topic?.includes(member.id)
    );

    if (existing) {
      return interaction.editReply({
        content: `❌ Ya tienes un ticket abierto: ${existing}. Ciérralo antes de abrir uno nuevo.`,
      });
    }

    // Create channel
    const ticketNumber = String(ticketCounter++).padStart(4, "0");
    const channelName = `${ticketInfo.prefix}-${ticketNumber}`;

    const ticketChannel = await guild.channels.create({
      name: channelName,
      type: ChannelType.GuildText,
      parent: CONFIG.TICKET_CATEGORY_ID || null,
      topic: `Ticket de ${member.user.tag} | ID: ${member.id} | Tipo: ${ticketInfo.label}`,
      permissionOverwrites: [
        {
          id: guild.id,
          deny: [PermissionFlagsBits.ViewChannel],
        },
        {
          id: member.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ReadMessageHistory,
            PermissionFlagsBits.AttachFiles,
          ],
        },
        {
          id: CONFIG.STAFF_ROLE_ID,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ReadMessageHistory,
            PermissionFlagsBits.AttachFiles,
            PermissionFlagsBits.ManageMessages,
          ],
        },
      ],
    });

    // Ticket embed
    const ticketEmbed = new EmbedBuilder()
      .setColor(ticketInfo.color)
      .setTitle(`${ticketInfo.emoji} ${ticketInfo.label}`)
      .setDescription(
        [
          `Hola ${member}, gracias por contactar con el soporte de **MineVolt**.`,
          "",
          "**Por favor indica:**",
          "• Descripción detallada de tu problema",
          "• Capturas de pantalla o evidencias (si aplica)",
          "• Tu nombre en el juego (Nick)",
          "",
          "> Un miembro del Staff te atenderá en breve. ¡Ten paciencia!",
        ].join("\n")
      )
      .addFields(
        { name: "👤 Usuario", value: `${member}`, inline: true },
        { name: "📂 Categoría", value: ticketInfo.label, inline: true },
        { name: "🔢 Nº Ticket", value: `#${ticketNumber}`, inline: true }
      )
      .setFooter({ text: "MineVolt Network • minevolt.fun" })
      .setTimestamp();

    const closeBtn = new ButtonBuilder()
      .setCustomId("ticket_close")
      .setLabel("🔒 Cerrar Ticket")
      .setStyle(ButtonStyle.Danger);

    const claimBtn = new ButtonBuilder()
      .setCustomId("ticket_claim")
      .setLabel("✋ Reclamar")
      .setStyle(ButtonStyle.Secondary);

    const btnRow = new ActionRowBuilder().addComponents(closeBtn, claimBtn);

    const staffMention = CONFIG.STAFF_ROLE_ID !== "ID_ROL_STAFF"
      ? `<@&${CONFIG.STAFF_ROLE_ID}>`
      : "@Staff";

    await ticketChannel.send({
      content: `${member} | ${staffMention}`,
      embeds: [ticketEmbed],
      components: [btnRow],
    });

    // Log
    await logAction(guild, "🎫 Ticket Abierto", member.user, ticketInfo, ticketChannel, ticketNumber);

    await interaction.editReply({
      content: `✅ Tu ticket ha sido creado: ${ticketChannel}`,
    });
  }

  // ── BUTTONS ──────────────────────────────────────────────────────────────────
  if (interaction.isButton()) {
    // Close ticket
    if (interaction.customId === "ticket_close") {
      const isStaff = interaction.member.roles.cache.has(CONFIG.STAFF_ROLE_ID);
      const isOwner = interaction.channel.topic?.includes(interaction.user.id);

      if (!isStaff && !isOwner) {
        return interaction.reply({
          content: "❌ No tienes permiso para cerrar este ticket.",
          ephemeral: true,
        });
      }

      const confirmEmbed = new EmbedBuilder()
        .setColor(CONFIG.COLOR_WARNING)
        .setTitle("⚠️ ¿Confirmar cierre?")
        .setDescription(
          "¿Estás seguro de que deseas cerrar este ticket? Esta acción no se puede deshacer."
        );

      const confirmBtn = new ButtonBuilder()
        .setCustomId("ticket_confirm_close")
        .setLabel("✅ Confirmar")
        .setStyle(ButtonStyle.Danger);

      const cancelBtn = new ButtonBuilder()
        .setCustomId("ticket_cancel_close")
        .setLabel("❌ Cancelar")
        .setStyle(ButtonStyle.Secondary);

      await interaction.reply({
        embeds: [confirmEmbed],
        components: [new ActionRowBuilder().addComponents(confirmBtn, cancelBtn)],
        ephemeral: true,
      });
    }

    // Confirm close
    if (interaction.customId === "ticket_confirm_close") {
      await interaction.reply({ content: "🔒 Cerrando ticket...", ephemeral: true });

      const closedEmbed = new EmbedBuilder()
        .setColor(CONFIG.COLOR_ERROR)
        .setTitle("🔒 Ticket Cerrado")
        .setDescription(`Ticket cerrado por ${interaction.user}.`)
        .setTimestamp();

      await interaction.channel.send({ embeds: [closedEmbed] });

      await logAction(
        interaction.guild,
        "🔒 Ticket Cerrado",
        interaction.user,
        { label: interaction.channel.name },
        interaction.channel,
        "—"
      );

      setTimeout(() => interaction.channel.delete().catch(() => {}), 5000);
    }

    // Cancel close
    if (interaction.customId === "ticket_cancel_close") {
      await interaction.reply({ content: "✅ Cierre cancelado.", ephemeral: true });
    }

    // Claim ticket
    if (interaction.customId === "ticket_claim") {
      const isStaff = interaction.member.roles.cache.has(CONFIG.STAFF_ROLE_ID);
      if (!isStaff) {
        return interaction.reply({
          content: "❌ Solo el Staff puede reclamar tickets.",
          ephemeral: true,
        });
      }

      const claimEmbed = new EmbedBuilder()
        .setColor(CONFIG.COLOR_SUCCESS)
        .setDescription(`✋ Este ticket ha sido reclamado por ${interaction.user}.`);

      await interaction.reply({ embeds: [claimEmbed] });
    }
  }
});

// ─── LOG ACTION ───────────────────────────────────────────────────────────────
async function logAction(guild, action, user, ticketInfo, channel, number) {
  if (CONFIG.LOG_CHANNEL_ID === "ID_CANAL_LOGS") return;

  const logChannel = guild.channels.cache.get(CONFIG.LOG_CHANNEL_ID);
  if (!logChannel) return;

  const embed = new EmbedBuilder()
    .setColor(CONFIG.COLOR_INFO)
    .setTitle(action)
    .addFields(
      { name: "👤 Usuario", value: `${user.tag} (${user.id})`, inline: true },
      { name: "📂 Tipo", value: ticketInfo.label, inline: true },
      { name: "📌 Canal", value: `${channel}`, inline: true }
    )
    .setTimestamp();

  await logChannel.send({ embeds: [embed] }).catch(() => {});
}

// ─── LOGIN ────────────────────────────────────────────────────────────────────
client.login(CONFIG.TOKEN);
